//
//  SimpleObject.h
//  myTV
//
//  Created by noark on 13-8-20.
//  Copyright (c) 2013年 noark. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SimpleObject : NSObject
@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *type;
@property (strong, nonatomic) NSString *category;

@end
