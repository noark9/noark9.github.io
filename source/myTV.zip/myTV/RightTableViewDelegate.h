//
//  RightTableViewDelegate.h
//  myTV
//
//  Created by noark on 13-8-17.
//  Copyright (c) 2013年 noark. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LeftTableViewDelegate.h"
#import "SimpleObject.h"

@protocol RightTableviewItemDraggingDelegate <NSObject>

- (void)dragItem:(SimpleObject *)item fromCategory:(NSString *)category;

@end

@interface RightTableViewDelegate : NSObject

@property (weak, nonatomic) NSString *selectedCategory;
@property (weak) IBOutlet NSTableView *rightTableView;
@property (weak) id<RightTableviewItemDraggingDelegate> draggingDestenation;
@property (weak) IBOutlet NSTableView *tableiew;

@end

