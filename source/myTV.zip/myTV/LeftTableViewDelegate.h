//
//  LeftTableViewDelegate.h
//  myTV
//
//  Created by noark on 13-8-17.
//  Copyright (c) 2013年 noark. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RightTableViewDelegate.h"
#import "SimpleObject.h"

@protocol SelectedItemDidChangeDelegate;

@interface LeftTableViewDelegate : NSObject

@property (weak) id<SelectedItemDidChangeDelegate> itemChangeDelegate;
@property (weak) IBOutlet NSTableView *tableview;

@property (weak) SimpleObject *currentDraggingItem;
@property (weak) NSString *dragFromCategory;

@end

@protocol SelectedItemDidChangeDelegate <NSObject>

- (void)selectedItemDidChangeTo:(NSString *)item;
- (void)finishDrag;

@end
