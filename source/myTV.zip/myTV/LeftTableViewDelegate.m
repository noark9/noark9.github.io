//
//  LeftTableViewDelegate.m
//  myTV
//
//  Created by noark on 13-8-17.
//  Copyright (c) 2013年 noark. All rights reserved.
//

#import "LeftTableViewDelegate.h"
#import "RightTableViewDelegate.h"
#import "DataEntity.h"

@interface LeftTableViewDelegate () <NSTableViewDataSource, NSTableViewDelegate, RightTableviewItemDraggingDelegate>

@end

@implementation LeftTableViewDelegate

@synthesize itemChangeDelegate = _itemChangeDelegate;

- (id)init
{
    if ([super init]) {
    }
    
    return self;
}

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView
{
    DataEntity *dataEntity = [DataEntity sharedInstance];
    return dataEntity.categories.count;
}

- (id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    DataEntity *dataEntity = [DataEntity sharedInstance];
    return [dataEntity.categories objectAtIndex:row];
}

- (void)tableView:(NSTableView *)tableView setObjectValue:(id)object forTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    NSLog(@"set");
    DataEntity *de = [DataEntity sharedInstance];
    [de.categories setObject:object atIndexedSubscript:row];
}

- (void)tableViewSelectionDidChange:(NSNotification *)notification
{
    if ([_itemChangeDelegate respondsToSelector:@selector(selectedItemDidChangeTo:)]) {
        DataEntity *dataEntity = [DataEntity sharedInstance];
        NSString *selectedItem = [dataEntity.categories objectAtIndex:[_tableview selectedRow]];
        [_itemChangeDelegate selectedItemDidChangeTo:selectedItem];
    }
}

- (void)dragItem:(SimpleObject *)item fromCategory:(NSString *)category
{
    _currentDraggingItem = item;
    _dragFromCategory = category;
}

- (BOOL)tableView:(NSTableView *)tableView acceptDrop:(id<NSDraggingInfo>)info row:(NSInteger)row dropOperation:(NSTableViewDropOperation)dropOperation
{
    /*
    NSArray *classes = [NSArray arrayWithObject:[DataEntity class]];
    NSDictionary *options = [[NSDictionary alloc] init];
    NSArray *items = [[info draggingPasteboard] readObjectsForClasses:classes options:options];
    DataEntity *dataEntity = [DataEntity sharedInstance];
    NSString *category = [dataEntity.categories objectAtIndex:row];
    [dataEntity moveItem:items[0] toCategory:category];
    
    [tableView reloadData];
    return YES;
     */
    DataEntity *dataEntity = [DataEntity sharedInstance];
    [dataEntity moveItem:_currentDraggingItem toCategory:[dataEntity.categories objectAtIndex:row]];
    if ([_itemChangeDelegate respondsToSelector:@selector(finishDrag)]) {
        [_itemChangeDelegate finishDrag];
    }
    return YES;
}

- (IBAction)addSth:(id)sender {
    [_tableview beginUpdates];
    DataEntity *de = [DataEntity sharedInstance];
    NSString *nt = @"Enter Name";
    [de.categories insertObject:nt atIndex:0];
    [_tableview insertRowsAtIndexes:[NSIndexSet indexSetWithIndex:0] withAnimation:NSTableViewAnimationEffectGap];
    [_tableview editColumn:0 row:0 withEvent:nil select:YES];
    [_tableview endUpdates];
}

- (NSDragOperation)tableView:(NSTableView *)tableView validateDrop:(id<NSDraggingInfo>)info proposedRow:(NSInteger)row proposedDropOperation:(NSTableViewDropOperation)dropOperation
{
    if (dropOperation == NSTableViewDropAbove) {
        return NSDragOperationNone;
    }
    return NSDragOperationMove;
}

@end
