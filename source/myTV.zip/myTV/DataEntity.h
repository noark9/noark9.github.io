//
//  DataEntity.h
//  myTV
//
//  Created by noark on 13-8-18.
//  Copyright (c) 2013年 noark. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SimpleObject.h"


@interface DataEntity : NSObject
@property (strong, nonatomic) NSMutableArray *categories;
@property (strong, nonatomic) NSMutableDictionary *items;

- (NSArray *)itemsForCategory:(NSString *)category;
- (NSArray *)removeItem:(NSString *)item inCategory:(NSString *)category;
- (NSArray *)addItem:(NSString *)item inCategory:(NSString *)category;
- (void)moveItem:(SimpleObject *)item toCategory:(NSString *)category;

+ (id)sharedInstance;

@end
