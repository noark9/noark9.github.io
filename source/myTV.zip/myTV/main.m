//
//  main.m
//  myTV
//
//  Created by noark on 13-8-17.
//  Copyright (c) 2013年 noark. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
