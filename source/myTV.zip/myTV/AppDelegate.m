//
//  AppDelegate.m
//  myTV
//
//  Created by noark on 13-8-17.
//  Copyright (c) 2013年 noark. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    // Insert code here to initialize your application
    _leftTableViewController.itemChangeDelegate = _rightTableViewDelegateController;
    [_rightTableView setDraggingSourceOperationMask:NSDragOperationEvery forLocal:NO];
    [_leftTableView registerForDraggedTypes:[NSArray arrayWithObject:NSPasteboardTypeString]];
    _rightTableViewDelegateController.draggingDestenation = _leftTableViewController;
}

@end
