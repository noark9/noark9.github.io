//
//  RightTableViewDelegate.m
//  myTV
//
//  Created by noark on 13-8-17.
//  Copyright (c) 2013年 noark. All rights reserved.
//

#import "RightTableViewDelegate.h"
#import "DataEntity.h"

@interface RightTableViewDelegate() <NSTableViewDataSource, NSTableViewDelegate, SelectedItemDidChangeDelegate>

@end

@implementation RightTableViewDelegate

@synthesize draggingDestenation = _draggingDestenation;

- (id)init
{
    if ([super init]) {
        
    }
    
    _selectedCategory = nil;
    
    return self;
}

- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView
{
    NSInteger itemCount = 0;
    if (_selectedCategory) {
        DataEntity *dataEntity = [DataEntity sharedInstance];
        itemCount = [dataEntity itemsForCategory:_selectedCategory].count;
    }
    return itemCount;
}

- (id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row
{
    SimpleObject *item = nil;
    if (_selectedCategory) {
        DataEntity *dataEntity = [DataEntity sharedInstance];
        item = [[dataEntity itemsForCategory:_selectedCategory] objectAtIndex:row];
    }
    return item.description;
}

- (void)tableView:(NSTableView *)tableView draggingSession:(NSDraggingSession *)session willBeginAtPoint:(NSPoint)screenPoint forRowIndexes:(NSIndexSet *)rowIndexes
{
    if([_draggingDestenation respondsToSelector:@selector(dragItem:fromCategory:)]) {
        DataEntity *dataEntity = [DataEntity sharedInstance];
        NSArray *items = [dataEntity itemsForCategory:_selectedCategory];
        [_draggingDestenation dragItem:[items objectAtIndex:[rowIndexes lastIndex]] fromCategory:_selectedCategory];
    }
}

- (void)finishDrag
{
    [_tableiew reloadData];
}

- (void)selectedItemDidChangeTo:(NSString *)item
{
    _selectedCategory = item;
    [_rightTableView reloadData];
}

- (id <NSPasteboardWriting>)tableView:(NSTableView *)tableView pasteboardWriterForRow:(NSInteger)row
{
    DataEntity *dataEntity = [DataEntity sharedInstance];
    SimpleObject *item = [[dataEntity itemsForCategory:_selectedCategory] objectAtIndex:row];
    return item;
}

@end
