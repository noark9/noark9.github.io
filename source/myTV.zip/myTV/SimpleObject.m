//
//  SimpleObject.m
//  myTV
//
//  Created by noark on 13-8-20.
//  Copyright (c) 2013年 noark. All rights reserved.
//

#import "SimpleObject.h"

@interface SimpleObject () <NSPasteboardWriting>

@end

@implementation SimpleObject

@synthesize name = _name;
@synthesize type = _type;
@synthesize category = _category;

- (NSString *)description
{
    return self.name;
}

- (NSArray *)writableTypesForPasteboard:(NSPasteboard *)pasteboard
{
    NSArray *writableTypes = nil;
    writableTypes = [NSArray arrayWithObject:NSPasteboardTypeString];
    return writableTypes;
}

- (id)pasteboardPropertyListForType:(NSString *)type
{
    if ([type isEqualToString:NSPasteboardTypeString]) {
        return self.description;
    } else if ([type isEqualToString:@"SimpleObject"]) {
        return self.description;
    }
    
    return nil;
}

@end
