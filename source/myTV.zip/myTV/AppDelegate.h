//
//  AppDelegate.h
//  myTV
//
//  Created by noark on 13-8-17.
//  Copyright (c) 2013年 noark. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "DataEntity.h"
#import "LeftTableViewDelegate.h"
#import "RightTableViewDelegate.h"

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;
@property (weak) IBOutlet NSTableView *leftTableView;
@property (weak) IBOutlet NSTableView *rightTableView;
@property (weak) IBOutlet LeftTableViewDelegate *leftTableViewController;
@property (weak) IBOutlet RightTableViewDelegate *rightTableViewDelegateController;

@end
