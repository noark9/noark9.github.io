//
//  DataEntity.m
//  myTV
//
//  Created by noark on 13-8-18.
//  Copyright (c) 2013年 noark. All rights reserved.
//

#import "DataEntity.h"

@interface DataEntity () <NSPasteboardReading>

@end

@implementation DataEntity

@synthesize categories = _categories;

- (id)init
{
    _categories = [NSMutableArray arrayWithObjects:@"father1", @"father2", @"noItems", @"Others", @"nothing", @"itemWithNIL", nil];
    
    SimpleObject *iOSobj1 = [[SimpleObject alloc] init];
    iOSobj1.name = @"f1item1";
    iOSobj1.type = @"type1";
    SimpleObject *iOSobj2 = [[SimpleObject alloc] init];
    iOSobj2.name = @"f1item2";
    iOSobj2.type = @"type2";
    SimpleObject *iOSobj3 = [[SimpleObject alloc] init];
    iOSobj3.name = @"f1item3";
    iOSobj3.type = @"type3";
    SimpleObject *iOSobj4 = [[SimpleObject alloc] init];
    iOSobj4.name = @"f1item4";
    iOSobj4.type = @"type4";
    
    SimpleObject *PHPobj1 = [[SimpleObject alloc] init];
    PHPobj1.name = @"f2item1";
    PHPobj1.type = @"type5";
    SimpleObject *PHPobj2 = [[SimpleObject alloc] init];
    PHPobj2.name = @"f2item2";
    PHPobj2.type = @"type6";
    SimpleObject *PHPobj3 = [[SimpleObject alloc] init];
    PHPobj3.name = @"f2item3";
    PHPobj3.type = @"type7";
    SimpleObject *PHPobj4 = [[SimpleObject alloc] init];
    PHPobj4.name = @"f2item4";
    PHPobj4.type = @"type8";
    
    SimpleObject *otobj = [[SimpleObject alloc] init];
    otobj.name = @"other1";
    otobj.type = @"othertype";
    SimpleObject *other = [[SimpleObject alloc] init];
    other.name = @"otherother";
    other.type = @"oh my type";
    
    NSMutableArray *itemsForIOS = [NSMutableArray arrayWithObjects:iOSobj1, iOSobj2, iOSobj3, iOSobj4, nil];
    NSMutableArray *itemsForPHP = [NSMutableArray arrayWithObjects:PHPobj1, PHPobj2, PHPobj3, PHPobj4, nil];
    NSMutableArray *itemsForOther = [NSMutableArray arrayWithObjects:otobj, other, nil];
    NSMutableArray *noitem = [[NSMutableArray alloc] init];
    _items = [[NSMutableDictionary alloc] init];
    [_items setValue:itemsForIOS forKey:@"father1"];
    [_items setValue:itemsForOther forKey:@"Others"];
    [_items setValue:itemsForPHP forKey:@"father2"];
    [_items setValue:noitem forKey:@"noitems"];
    [_items setValue:nil forKey:@"itemWithNIL"];
    
    return self;
}

- (NSArray *)itemsForCategory:(NSString *)category
{
    return [_items valueForKey:category];
}

- (NSArray *)removeItem:(NSString *)item inCategory:(NSString *)category
{
    return nil;
}

- (NSArray *)addItem:(NSString *)item inCategory:(NSString *)category
{
    return nil;
}

- (NSString *)getCategoryOfItem:(SimpleObject *)item
{
    NSString *ret = nil;
    BOOL findItem = NO;
    for (NSString *category in _categories) {
        NSMutableArray *items = [_items valueForKey:category];
        for (SimpleObject *aItem in items) {
            if ([item.name isEqualToString:aItem.name]) {
                findItem = YES;
                break;
            }
        }
        if (findItem) {
            ret = category;
            break;
        }
    }
    
    return ret;
}

- (void)moveItem:(SimpleObject *)item toCategory:(NSString *)category
{
    NSMutableArray *fromCategory = [_items valueForKey:[self getCategoryOfItem:item]];
    NSMutableArray *toCategory = [_items valueForKey:category];
    
    [fromCategory removeObject:item];
    [toCategory addObject:item];    
}

+ (NSArray *)readableTypesForPasteboard:(NSPasteboard *)pasteboard
{
    return [NSArray arrayWithObject:NSPasteboardTypeString];
}

+ (id)sharedInstance
{
    static dispatch_once_t pred = 0;
    __strong static id _sharedObject = nil;
    dispatch_once(&pred, ^{
        _sharedObject = [[self alloc] init];
    });
    return _sharedObject;
}

@end
